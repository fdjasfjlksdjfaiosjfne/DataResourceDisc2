execute if items entity @s weapon.mainhand *[!jukebox_playable] run tellraw @s {text:'You must be holding an item capable of being played in a jukebox',color:'red'}
execute if items entity @s weapon.mainhand air run tellraw @s {text:'You must be holding an item capable of being played in a jukebox',color:'red'}
execute if items entity @s weapon.mainhand *[!jukebox_playable] run return fail
execute if items entity @s weapon.mainhand air run return fail
execute if items entity @s weapon.mainhand music_disc_11 run item modify entity @s weapon.mainhand custom_discs:restore/11
execute if items entity @s weapon.mainhand music_disc_13 run item modify entity @s weapon.mainhand custom_discs:restore/13
execute if items entity @s weapon.mainhand music_disc_cat run item modify entity @s weapon.mainhand custom_discs:restore/cat
execute if items entity @s weapon.mainhand music_disc_5 run item modify entity @s weapon.mainhand custom_discs:restore/5
execute if items entity @s weapon.mainhand music_disc_stal run item modify entity @s weapon.mainhand custom_discs:restore/stal
execute if items entity @s weapon.mainhand music_disc_mellohi run item modify entity @s weapon.mainhand custom_discs:restore/mellohi
execute if items entity @s weapon.mainhand music_disc_pigstep run item modify entity @s weapon.mainhand custom_discs:restore/pigstep
execute if items entity @s weapon.mainhand music_disc_otherside run item modify entity @s weapon.mainhand custom_discs:restore/otherside
execute if items entity @s weapon.mainhand music_disc_bounce run item modify entity @s weapon.mainhand custom_discs:restore/bounce
execute if items entity @s weapon.mainhand music_disc_blocks run item modify entity @s weapon.mainhand custom_discs:restore/blocks
execute if items entity @s weapon.mainhand music_disc_chirp run item modify entity @s weapon.mainhand custom_discs:restore/chirp
execute if items entity @s weapon.mainhand music_disc_far run item modify entity @s weapon.mainhand custom_discs:restore/far
execute if items entity @s weapon.mainhand music_disc_mall run item modify entity @s weapon.mainhand custom_discs:restore/mall
execute if items entity @s weapon.mainhand music_disc_ward run item modify entity @s weapon.mainhand custom_discs:restore/ward
execute if items entity @s weapon.mainhand music_disc_wait run item modify entity @s weapon.mainhand custom_discs:restore/wait
execute if items entity @s weapon.mainhand music_disc_relic run item modify entity @s weapon.mainhand custom_discs:restore/relic
execute if items entity @s weapon.mainhand music_disc_precipice run item modify entity @s weapon.mainhand custom_discs:restore/precipice
execute if items entity @s weapon.mainhand music_disc_creator run item modify entity @s weapon.mainhand custom_discs:restore/creator
execute if items entity @s weapon.mainhand music_disc_tears run item modify entity @s weapon.mainhand custom_discs:restore/tears
execute if items entity @s weapon.mainhand music_disc_creator_music_box run item modify entity @s weapon.mainhand custom_discs:restore/creator_music_box
execute if items entity @s weapon.mainhand music_disc_lava_chicken run item modify entity @s weapon.mainhand custom_discs:restore/lava_chicken
scoreboard players set @s select_disc 0
scoreboard players enable @s select_disc