execute as @a[predicate=custom_discs:request_disc_ui] run dialog show @s custom_discs:disc_selection
execute as @a[predicate=custom_discs:request_disc_ui] run scoreboard players enable @a[predicate=custom_discs:request_disc_ui] disc_art_ui
execute as @a[predicate=custom_discs:request_disc_ui] run scoreboard players set @a[predicate=custom_discs:request_disc_ui] disc_art_ui 0
execute as @a[scores={select_disc=1..}] run function custom_discs:apply_disc
execute as @a[scores={select_disc=-1}] run function custom_discs:restore_disc
execute as @a[predicate=custom_discs:request_pack_info] run function custom_discs:info