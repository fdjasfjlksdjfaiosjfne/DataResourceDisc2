tellraw @s {'translate': 'custom_discs.version_check.2', 'fallback': '§cYour resource pack is outdated!§r'}
tellraw @s ['Texture pack version: ', {'translate': 'custom_discs.respack_version'}]
tellraw @s 'Data pack version: 2'
scoreboard players set @s disc_pack_info 0
scoreboard players enable @s disc_pack_info