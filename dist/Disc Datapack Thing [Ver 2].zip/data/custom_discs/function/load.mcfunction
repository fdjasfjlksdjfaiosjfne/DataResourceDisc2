scoreboard objectives add open_disc_ui trigger
scoreboard objectives add select_disc trigger
scoreboard objectives add disc_pack_info trigger
scoreboard players set @a open_disc_ui 0
scoreboard players set @a select_disc 0
scoreboard players set @a disc_pack_info 0
scoreboard players enable @a open_disc_ui
scoreboard players enable @a select_disc
scoreboard players enable @a disc_pack_info