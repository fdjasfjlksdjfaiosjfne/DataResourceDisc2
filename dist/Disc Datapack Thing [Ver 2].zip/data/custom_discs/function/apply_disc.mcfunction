execute if items entity @s weapon.mainhand *[!jukebox_playable] run tellraw @s {text:'You must be holding an item capable of being played in a jukebox',color:'red'}
execute if items entity @s weapon.mainhand air run tellraw @s {text:'You must be holding an item capable of being played in a jukebox',color:'red'}
execute if items entity @s weapon.mainhand *[!jukebox_playable] run return fail
execute if items entity @s weapon.mainhand air run return fail
execute as @s[scores={select_disc=1}] run item modify entity @s weapon.mainhand custom_discs:trans/mili-through_patches_of_violet
execute as @s[scores={select_disc=2}] run item modify entity @s weapon.mainhand custom_discs:trans/mili-compass
execute as @s[scores={select_disc=3}] run item modify entity @s weapon.mainhand custom_discs:trans/kano-memories_of_kindness
execute as @s[scores={select_disc=4}] run item modify entity @s weapon.mainhand custom_discs:trans/kero_kero_bonito-well_rested
execute as @s[scores={select_disc=5}] run item modify entity @s weapon.mainhand custom_discs:trans/hoyomix-song_to_the_mirrored_moon
execute as @s[scores={select_disc=6}] run item modify entity @s weapon.mainhand custom_discs:trans/thepal-song_for_the_masses
execute as @s[scores={select_disc=7}] run item modify entity @s weapon.mainhand custom_discs:trans/eminem-mockingbird
execute as @s[scores={select_disc=8}] run item modify entity @s weapon.mainhand custom_discs:trans/vane_lily-butcher_vanity
execute as @s[scores={select_disc=9}] run item modify entity @s weapon.mainhand custom_discs:trans/thefatrat-ray_tracer
execute as @s[scores={select_disc=10}] run item modify entity @s weapon.mainhand custom_discs:trans/dazbee-echoes_of_longing
execute as @s[scores={select_disc=11}] run item modify entity @s weapon.mainhand custom_discs:trans/xi-ascension_to_heaven
execute as @s[scores={select_disc=12}] run item modify entity @s weapon.mainhand custom_discs:trans/tanger-strangers_once_again
execute as @s[scores={select_disc=13}] run item modify entity @s weapon.mainhand custom_discs:trans/mailpup-puppyplay
execute as @s[scores={select_disc=14}] run item modify entity @s weapon.mainhand custom_discs:trans/arraegen-glass_chapel
execute as @s[scores={select_disc=15}] run item modify entity @s weapon.mainhand custom_discs:trans/arraegen-menace
scoreboard players set @s select_disc 0
scoreboard players enable @s select_disc